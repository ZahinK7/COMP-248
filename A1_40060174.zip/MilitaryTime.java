//------------------------------------------------------------------------------------
//Assignment #1-
//File name: MilitaryTime.java
//Written by:Nancy Acemian
//Edited by:Zahin Khan - 40060174
//Comp 248-Summer 2019
//-----------------------------------------------------------------------------------
import java.util.Scanner;
public class MilitaryTime {

	public static void main(String[] args) {
	
	
		Scanner keyIn = new Scanner(System.in);
		final int const1 = 60;
		final int const2 = 100;
		int Time1, Time2, Diff_time;
		int Time1_hour, Time2_hour, Time1_min, Time2_min, Diff_hour, Diff_min;
		System.out.print("Enter the starting time and the ending time in military format: ");/*Asking the 
		user to enter time using scanner */
		Time1 = keyIn.nextInt();
		Time2 = keyIn.nextInt();
		Time1_hour = Time1/const2; //Starting hours
		Time2_hour = Time2/const2;//Ending hours
		Time1_min = Time1%const2;//Starting minutes
		Time2_min = Time2%const2;//Ending minutes
		Time1 = Time1_hour*const1+Time1_min;
		Time2 = Time2_hour*const1+Time2_min;
		Diff_time = Time2-Time1;
		Diff_hour = Diff_time/const1; //Dividing to get hours
		Diff_min = Diff_time%const1;  //Using the modulo function to get minutes
		System.out.println( "Results "+ Diff_hour+ '\t' + Diff_min);		
		keyIn.close();
		}
		

	}


