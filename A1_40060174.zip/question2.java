//-------------------------------------------------------------------------------------------------
//Assignment #1-
// Written by: Zahin Khan (40060174)
// For COMP 248 Section EC � Summer 2019
/*Comments:Using Scanner, prompt the user to put three words separated by 
a blank and display by starting with a capital letter and everything lower case and each word in reverse order*/
//------------------------------------------------------------------------------------------------
import java.util.Scanner;
public class question2 {

	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in); //Using the Scanner tool to allow user input
		System.out.println("Enter 3 words separeted by a blank: ");
		String words1 = keyboard.next(); //Each word is stored as a string
		String words2 = keyboard.next();
		String words3 = keyboard.nextLine();	
		String words4 = words1.toLowerCase(); //Converting to lower case 
		String words5 = words2.toLowerCase(); //Converting to lower case
		String words6 = words3.substring(1,2).toUpperCase()+words3.substring(2).toLowerCase(); 
		//First letter is converted to capital letter while the rest is converted to lower case
		System.out.println();
		//Display in console as output
		System.out.println("Words in reverse order: "+'\n'+words6+" "+words5+" "+words4+'\n');
		System.out.println("All done!!");
keyboard.close();
		

	}

}
