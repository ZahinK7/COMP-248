//----------------------------------------------------------------------------------------
//Assignment #1-
// Written by: Zahin Khan (40060174)
// For COMP 248 Section EC � Summer 2019
//Comments:Printing a message using escape sequences
//-----------------------------------------------------------------------------------------
	public class question1 {
	/*Using escape sequence like \n for return and \" for quotes in order to display in the 
	 * console using System.out.println
	 */
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.out.println("Welcome to my First Java program! "+ '\n'+
					"The statement System.out.println.(\"Hello\");will display"+'\n'+"Hello " +
					"then move the cursor to the next line while the statement"+'\n'+ 
					"System.out.println.(\"Hello\"); will display"+'\n'+
					"Hello and the cursor will stay on the same line. "+'\n'+'\n'+"All done!");
		
		}

	}



