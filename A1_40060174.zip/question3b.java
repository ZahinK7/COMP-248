//------------------------------------------------------------------------------------------------
//Assignment #1-
// Written by: Zahin Khan (40060174)
// For COMP 248 Section EC � Summer 2019
/*Comments:Modifying a program in order to prompt user to enter the starting time and ending time,
then the program the elapsed time and the period of the day*/
//-----------------------------------------------------------------------------------------------
import java.util.Scanner;
public class question3b {

	public static void main(String[] args) {
		Scanner keyIn = new Scanner(System.in);
		final int const1 = 60;
		final int const2 = 100;
		int Time1, Time2, Diff_time;
		int Time1_hour, Time2_hour, Time1_min, Time2_min, Diff_hour, Diff_min;
		System.out.println("\\--- Tic--- Toc--- Tic- Toc--- Tic-- Toc---\\"); //Display message
		System.out.println("\\                                          \\");
		System.out.println("\\    Elapsed Time Calculator - Version 2   \\");
		System.out.println("\\                                          \\");
		System.out.println("\\--- Tic--- Toc--- Tic- Toc--- Tic-- Toc--- \\");
		System.out.println();
		System.out.print("Enter the starting time and the ending time in military format: ");/*Asking the 
		user to enter time using scanner */
		Time1 = keyIn.nextInt();
		Time2 = keyIn.nextInt();
		 
		String period1 = "0";
		String period2 = "0";
		//Using if and else statement to determine the period of the day
		if (Time1 < 0600)
			period1 ="in the middle of the night";
		else if (Time1 >= 0600 && Time1 < 1200)
			period1 = "in the morning";
		else if (Time1 >= 1200 && Time1 < 1800)
			period1 = "during the day";
		else period1 ="in the evening";
		
		if (Time2 < 0600)
			period2 = "in the middle of the night";
		else if(Time2 >= 0600 && Time2 < 1200)
			period2 = "in the morning";
		else if (Time2 >= 1200 && Time2 < 1800)
			period2 = "during the day";
		else
			period2 = "in the evening";
		
		if (Time2 < Time1)
		Time2 +=2400;
			
		Time1_hour = Time1/const2; //Starting hours
		Time2_hour = Time2/const2;//Ending hours
		Time1_min = Time1%const2;//Starting minutes
		Time2_min = Time2%const2;//Ending minutes
		Time1 = Time1_hour*const1+Time1_min;
		Time2 = Time2_hour*const1+Time2_min;
		Diff_time = Time2-Time1;
		Diff_hour = Diff_time/const1; //Dividing to get hours
		Diff_min = Diff_time%const1;  //Using the modulo function to get minutes
		//Displaying messages
		System.out.println();
		System.out.println("Your activity started "+period1+" and ended "+period2+" and took "+Diff_hour+
				" hrs and "+Diff_min+" minutes");
		System.out.println();
		System.out.println("All done!");
		
		
		keyIn.close();
			
	}

}
