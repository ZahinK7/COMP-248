// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Assignment 2
// Written by: Zahin Khan 40060174
// For COMP 248 Section EC � Summer 2019
// Comments: Allowing the user to create an array of NxN and displaying the sum of top and bottom rows, first and last rows and diagonally.
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import java.util.Scanner;
public class A3Q1 {
	
	
	//Creating methods in order to use them in the main, looks clean
	private int [][] mArray (int sizeOfArray){ //Creating an array with size of NxN which user will input
		int nxnArray [][] = new int[sizeOfArray][sizeOfArray];

		for (int i =0 ; i <sizeOfArray; i++) { //Putting entries based on the size of the array
		for (int j = 0 ; j < sizeOfArray; j++)
				if (i==j) {
				nxnArray [i][j] =0;
				}else if ((i+j) % 2 !=0) {
				nxnArray [i][j] = i+j;
				}else if ((i+j) % 2 ==0) {
				nxnArray [i][j] = 2*i -j;
				}
		}
		return nxnArray;
	}	
	public static void printArray(int [] [] nxnArray) {//Displaying the array to user based on the choice of the size of the array
		int length = nxnArray.length;	 // i is row and j is column
		for (int i = 0; i < length; i++) {
		for (int j = 0; j < length; j++) {
			System.out.print(nxnArray[i][j] + "\t");
			}
			System.out.println();
		}
	}
	public static String arrayToString(int[] lrDiagonalArray){	
			String s = "";
		    for(int i = 0; i < lrDiagonalArray.length; i++){
		    s += lrDiagonalArray[i] +"\t";
		}
		return s;	
	}
	private int getSum(int[][] nxnArray) { //Method that sum the elements of 2d array
		int sumResult =0;
		for (int i =0 ; i < nxnArray.length; i++) {
		for(int j =0 ; j < nxnArray[0].length; j++) {
		sumResult += nxnArray[i][j];  
			}
		}
		return sumResult;
	}	
	private int getSum(int[] nxnArray){ //Method that sum the elements of a 1d array
		int sum = 0;
		for(int i = 0; i < nxnArray.length; i++){
			sum = sum+ nxnArray[i];
		}
		return sum;
	}
	   private int[] gettLbR(int [][] nxnArray) { //Calculating method of sum of entries diagonally from top left to bottom right
		int[] leftDiag = new int[nxnArray.length];
		for (int i =0 ; i < nxnArray.length; i++) {
			leftDiag[i] = nxnArray[i][i];
		}
		return leftDiag;
	}
	private int[] tRbL(int [][] nxnArray) {         //Calculating method of sum of entries diagonally from top right to bottom left
		int[] rightDiag = new int[nxnArray.length];
		int index = 0;
		for (int i =nxnArray.length-1 ; i >=0; i--) {
			rightDiag[i] = nxnArray[i][index];
			index++;
		}
		return rightDiag;
	}
	 private int[] getColumn(int[][] arr, int columnIndex){
	       int columnArr[] = new int[arr.length];    
	       for(int i = 0; i < arr.length ; i++){
	           columnArr[i] = arr[i][columnIndex];
	       }	      
	       return columnArr;
	   }
	 
	public static void main (String args[]) {

		System.out.println(String.format("%5s", "")+"--------------------------------------------------"); // Welcoming user to program 
		System.out.println(String.format("%4s", "")+"\t"+"Let's practice manipulating a 2D array");
		System.out.println(String.format("%5s", "")+"--------------------------------------------------");

		A3Q1 mat = new A3Q1();
		Scanner input = new Scanner(System.in);
		int sizeOfArray;

		do {
			System.out.print("What sizeOfArray square array do you want? (must be >= 3) ");  //Print instruction (assuming user is perfect) and go to next line
			sizeOfArray = input.nextInt();

		}while (sizeOfArray <3);

		int[][] nxnArray =  mat.mArray(sizeOfArray);
		 System.out.println(); //Next line
		 System.out.println("The array looks like the following:"); //Print message and go to next line
		 mat.printArray(nxnArray);

		 System.out.println("\nSum of all the elements of the " +sizeOfArray+ "x" +sizeOfArray+ " array is "+mat.getSum(nxnArray)); //Print message and go to next line
		
		 System.out.println("\nDiagonal from top left to bottom right contains:"); //Print message and go to next line
		 int[] lrDiagonalArray = mat.gettLbR(nxnArray); 
		 System.out.println(mat.arrayToString(lrDiagonalArray)+"\t Sum is "+mat.getSum(lrDiagonalArray)); //Print message and go to next line
		
		 System.out.println("\nDiagonal from top right to bottom left contains:");
	     int[] rlDiagonalArray = mat.tRbL(nxnArray); //get diagonal from top right to bottom left
	     System.out.println(mat.arrayToString(rlDiagonalArray)+"\t Sum is "+mat.getSum(rlDiagonalArray));
	      
	     System.out.println("\nTop row contains:");
	     int[] firstRowArray = nxnArray[0];
	     System.out.println(mat.arrayToString(firstRowArray)+"\t Sum is "+mat.getSum(firstRowArray)); //Calculating sum, printing message and go to next line
	      
	     System.out.println("\nBottom row contains:");
	     int[] lastRowArray = nxnArray[sizeOfArray-1];
	     System.out.println(mat.arrayToString(lastRowArray)+"\t Sum is "+mat.getSum(lastRowArray)); //Calculating sum, printing message and go to next line
	      
	     System.out.println("\nFirst column contains:");
	     int[] firstColumnArray = mat.getColumn(nxnArray, 0);
	     System.out.println(mat.arrayToString(firstColumnArray)+"\t Sum is "+mat.getSum(firstColumnArray)); //Calculating sum, printing message and go to next line
	      
	     System.out.println("\nLast column contains:");
	     int[] lastColumnArray = mat.getColumn(nxnArray, sizeOfArray-1);
	     System.out.println(mat.arrayToString(lastColumnArray)+"\t Sum is "+mat.getSum(lastColumnArray)); //Calculating sum, printing message and go to next line
	      
	      
         System.out.println("\nThat was a good exercise in manipulating a 2D-Array!"); //Print message and go to next line
	}
	

	

	
}

