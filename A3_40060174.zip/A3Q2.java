// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Assignment 3
// Written by: Zahin Khan 40060174
// For COMP 248 Section EC � Summer 2019
// Comments: Allowing the user to enter numbers which converted to complex number and the information is then used in various calculations (this is driver file).
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import java.util.Scanner;
public class A3Q2 {
	public static void main (String args[]) {

		Scanner input = new Scanner(System.in);

		System.out.println(String.format("%5s", "") +"--------------------------------------"); // Welcoming user to program
		System.out.println(String.format("%4s", "")+"\t"+"Let's play with complex numbers!");
		System.out.println(String.format("%5s", "") +"--------------------------------------");

		Complex objectA = new Complex();
		Complex objectB = new Complex(objectA);

		System.out.println("\nComplex number created with default constructor is: " +objectB.toString());//Giving information to user then jump a line

		System.out.print("Enter the real part of the 2nd complex number: ");//Prompting user for data(assuming perfect user)
		double r = input.nextDouble();
		System.out.print("Enter the imaginary part of the 2nd complex number: ");//Prompting user for data (assuming perfect user)
		double i= input.nextDouble();
		System.out.println("Entered complex number is: " +r+" + "+i+"*i");

		Complex objectC = new Complex(r,i);
		boolean objectD = objectC.equals(objectB);
		String equal ="0";

		if(objectC.equals(objectB)==false) {//This methods compare two objects
			equal = "not equal";

		}else  
			equal = "equal";

		System.out.println("\nThe complex numbers "+objectB.toString()+ " and " +r+ " + " +i+ "*i " + "are " +equal+".");//Displaying if the two numbers are equal

		double temp = r;
		r = i;
		i = temp;

		System.out.println("\nSwapping the real and imaginary part of "+objectC.toString()+ " results in " +r+" + " +temp+ "*i");//Displaying that the number have been swapped

		Complex objectE = new Complex (r,i); //Creating an object
		boolean objectF = objectE.equals(objectE);

		System.out.println(objectE.toString() + " is equal to " +objectE.toString()+ " is now " +objectF);//Displaying message

		System.out.print("\nEnter a number please: ");//Prompting user to enter data
		double num = input.nextDouble();		

		Complex objectG = new Complex(r,i); //Creating object
		Complex objectH = new Complex(num,num);
		Complex sum = new Complex();
		sum = sum.addition(objectG, objectH);
		System.out.println(objectE.toString()+ " has been changed to " +sum.toString());
		
		if (objectE.equals(sum)==false) {
			equal= "not equal";
			
		}else 
			equal = "equal";
		
		System.out.println("The complex numbers "+sum.toString()+" and " +objectE.toString()+ " are " +equal+".");//
		
		Complex sum1 = new Complex();    //Calculating the addition based on given information
		sum1 = sum1.addition(sum, objectE); 
		
		System.out.println("\nAdding "+sum.toString()+ " to "+objectE.toString()+" results in the complex number "+sum1.toString());
		
		Complex product = new Complex();  //Calculating the multiplication based on given information
		product = product.multiplication(sum1, objectE);
		
		System.out.println("Multiplying "+sum1.toString()+" by "+objectE.toString()+" results in the complex number "+product.toString());//Display of the calculation of the complex number
		
		System.out.println("\nSo after all this manipulation the original complex have morphed into"+"\n"
		+sum1.toString()+ " and "+product.toString()); //Displaying the complex numbers of the user
		
		System.out.println("\nYou should now be comfortable with defining a class and manipulating objects, right?"+"\n"
		+"On to bigger and better things..."); //Displaying message and jump a line
	}
	
}
