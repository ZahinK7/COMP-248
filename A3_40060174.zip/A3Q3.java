// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Assignment 2
// Written by: Zahin Khan 40060174
// For COMP 248 Section EC � sumResultmer 2019
// Comments: Asking user how many complex numbers they wish and creating an array for the elements and telling them which index its located (driver file).
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import java.util.Scanner;
public class A3Q3 {

	static double rDouble() { //Method that returns a double
		double rDouble = Math.random();
		rDouble = rDouble * 100;
		double rDoubleSign = Math.random();
		if (rDoubleSign <= 0.5)
		{
			rDouble = rDouble * (-1);
		}
		return rDouble;
	}
	public static void main(String args[]) {

		System.out.println(String.format("%5s", "") +"------------------------------------------------------"); // Welcoming message to user
		System.out.println(String.format("%4s", "")+"\t"+"Let's play with arrays of complex number objects!");
		System.out.println(String.format("%5s", "") +"------------------------------------------------------");

		Scanner input = new Scanner(System.in);
		int num;
		do
		{
			System.out.print("How many complex numbers do you want (max of 12 at least 4): ");//Asking user to follow instruction and enter information
			num = input.nextInt();
		}
		while (num > 12 || num < 4);

		System.out.println("Here are the complex numbers generated:");
		
		Complex [] arraY = new Complex[num];//Method that creates an array based on data
		double randomReal = 0.0;
		double randomImag = 0.0;
		for (int i = 0; i < arraY.length -2; i++ ) {
			randomReal = rDouble();
			randomImag = rDouble();
		    
			arraY[i] = new Complex (randomReal,randomImag);
		}
		int randomInt =0;

		while(true) {
			randomInt = (int) (Math.random()*num);//Method that prints second to last index in the program
			if (randomInt <= num-3) {
				arraY [arraY.length-2] = arraY[randomInt];
				int y = randomInt;
				arraY [y] = new Complex (arraY[randomInt]);
				break;
			}
		}
		while(true) {
			randomInt = (int) (Math.random()*num-1); //Method that prints the last index in the program
			if(randomInt <= num-2) {
				arraY[arraY.length-1] = arraY[randomInt];
				int y = randomInt;
				arraY [y] = new Complex (arraY[randomInt]);
				break;
			}
			System.out.println(arraY[num]);
		}

		Complex sumResult = new Complex(0,0);// This creates a new Complex object called sumResult which stores the sumResult of all values in the arraYay
		Complex productResult = new Complex (1,1);

		for(int i =0; i < arraY.length;i++) {// This prints out the array with every index location
			sumResult = sumResult.addition(sumResult, arraY[i]);
			productResult = productResult.multiplication(productResult, arraY[i]);
			System.out.println("In index location "+i+ " is complex number " +arraY[i] );
		}
		 int smallest = 0;

		 for (int i =1; i < arraY.length; i++) { // This loop allows us to find the smallest number by using our method find Smaller
			boolean small = A3Q3.findSmaller(arraY[i], arraY[smallest]);
			if(small==true) {
			smallest = i;
		}
	}

		System.out.println("\nThe smallest complex number is in index location "+smallest+" and is " + arraY[smallest]);//Displaying to user the smallest complex number

		int largest = 0;

		for (int j =1; j < arraY.length; j++) { // This loop allows us to find the largest number by using our method findLarger
			boolean large = A3Q3.findLarger(arraY[j],arraY[largest]);
			if(large==true) {
			largest = j;
			}
		}
		System.out.println("\nThe largest complex number is in index location "+largest+" and is "+arraY[largest]); //Displaying user the largest complex number

		System.out.println("\nThe sum of all complex numbers is "+sumResult); //Displaying the sum to user

		System.out.println("\nThe product of all complex numbers is "+productResult.toString()); //Displaying the product to user

		System.out.println("\nHere are the complex numbers with real numbers changed:");//Displaying message to user

		for (int i = 0; i < arraY.length; i++) { // This loop changes the sign of the real part of the number when index is even
		if (i %2 ==0) {
		arraY[i].setReal(arraY[i].getReal()*-1);
			}

		System.out.println("In index location "+i+ " is complex number " +arraY[i] );//Displaying elements from an array	
		
		}

		System.out.println("\nHere are the complex numbers with imaginary numbers changed:");//Displaying message

		for (int i = 0; i < arraY.length; i++) { // This loop changes the sign of the imaginary part of the number when index is odd
		if (i %2 !=0) {
				arraY[i].setImaginary(arraY[i].getImaginary()*-1);
		}
			System.out.println("In index location "+i+ " is complex number " +arraY[i] );		

		}
		System.out.println("\nYou should now be comfortable with creating arrays of objects, right?" +"\n" +
		"And static methods in a driver, right ?" +"\n"+
		"OKAY, you are now ready for the final exam."); //Closing message to user
	}
		public static boolean findSmaller(Complex C1,Complex C2) { // Method to compare between two Complex number 
		if (C1.getReal() == C2.getReal() && C1.getImaginary() < C2.getImaginary()) {
		return true;
		
			}else if (C1.getReal() < C2.getReal()) {
				return true;
			}
			return false;
		}
		public static boolean findLarger(Complex C1, Complex C2) { // Method to compare between two Complex number
		if (C1.getReal()==C2.getReal() && C1.getImaginary() > C2.getImaginary()) {
		return true;

			}else if (C1.getReal() > C2.getReal()) {
				return true;
			}
			return false;
		}









	}	