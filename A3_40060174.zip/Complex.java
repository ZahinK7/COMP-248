// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Assignment 2
// Written by: Zahin Khan 40060174
// For COMP 248 Section EC � Summer 2019
// Comments: This is the complex class for the A3Q2 and A3Q3.
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
public class Complex {

	private double realNumb;
	private double imagNumb;

	public Complex(){ // This is a default constructor
		this.realNumb = 0.0;
		this.imagNumb = 0.0;
	}

	public Complex(double realNumb, double imagNumb) { //This is the method 
		this.realNumb = realNumb;
		this.imagNumb = imagNumb;
	}
	public Complex(Complex copy) { //This is a copy constructor
		this.realNumb = copy.realNumb;
		this.imagNumb = copy.imagNumb;
	}

	public double getReal() {//This method returns a real number
		return realNumb;
	} 

	public double getImaginary() { //This method returns a imaginary number
		return imagNumb;
	}

	public void setReal(double realNumb) {//This method sets a real number
		this.realNumb=realNumb;
	}

	public void setImaginary (double imaginary) {//This method sets an imaginary number
		this.imagNumb = imagNumb;
	}

	public Complex addition(Complex comp1, Complex comp2) { //This method does an addition
		Complex add = new Complex();
		add.realNumb = comp1.realNumb + comp2.realNumb;
		add.imagNumb = comp1.imagNumb + comp2.imagNumb;
		return add;	  
	}

	public static Complex multiplication(Complex compA, Complex compB) { //This method does a multiplication
		Complex c = new Complex(0.0,0.0);
		c.realNumb = (compA.realNumb*compB.realNumb -compA.imagNumb*compB.imagNumb); 
		c.imagNumb = (compA.realNumb*compB.imagNumb+compA.imagNumb*compB.realNumb);
		return c;
	}
	public String toString() {
		if (imagNumb < 0) {
			return "" + String.format("%.2f", realNumb) + " + " + "-" + String.format("%.2f", Math.abs(imagNumb)) + "*i";
		} else {
			return "" + String.format("%.2f", realNumb) + " + " + String.format("%.2f", Math.abs(imagNumb)) + "*i";
		}
	}
	public boolean equals(Object object) { //This is a equals method
		if (object != null && object instanceof Complex) {
			Complex copy = (Complex) object;
			return realNumb == copy.realNumb  && imagNumb == copy.imagNumb;
		}
		return false;
	}


}

