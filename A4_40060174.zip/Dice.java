// -------------------------------------------------------
// Assignment (4)
// Written by: (Zahin Khan 40060174)
// For COMP 248 Section (EC-E) � Fall 2019
// --------------------------------------------------------


public class Dice { //Creating class dice
	private int dice1; //Declaring two attributes 
	private int dice2;


	public Dice() {//Default constructor
		dice1=0;
		dice2=0;
	}

	public int getDice1() {//Accessor method for dice 1 and dice2
		return dice1;

	}


	public int getDice2( ) {
		return dice2;
	}

	public int rollDice() { //Creating method to roll dice with random method of math
		dice1 = 1 + (int)(Math.random() * ((6 - 1) + 1));
		dice2 = 1 + (int)(Math.random() * ((6 - 1) + 1));
		{
			int sum = (dice1+dice2);
			return sum;
		}
	}

	public boolean isDouble() { //Creating a method called double, when two dice 1 and dice 2 have same value
		if (dice1==dice2) {
			return true;

		}
		else {
			return false;
		}
	}

	public String toString() { //to string method which returns dice 1 and dice 2 results
		return "Die1: "+dice1 +" Die2:"+ dice2;
	}


}








