// -------------------------------------------------------
// Assignment (4)
// Written by: (Zahin Khan 40060174)
// For COMP 248 Section (EC-E) � Fall 2019
// --------------------------------------------------------

import java.util.Scanner; //importing scanner
public class Letusplay { //Main driver
	static Scanner key = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub




		//Welcoming users to game
		System.out.println("*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*");

		System.out.println("*                                                   *");

		System.out.println("*         WELCOME to Zahin's 3D Warrior Game!*      *");

		System.out.println("*                                                   *");

		System.out.println("*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*_*");

		System.out.println();

		//Asking user size of the board and how many levels does he/she want
		System.out.println("The default game board has 3 levels and each level has a 4x4 board.");
		System.out.println("You can use this default board size or change the size");
		System.out.println(" 0 to use the default board size ");
		System.out.println("-1 to enter your own size");
		System.out.println("==>What do you want to do?");

		int numa= key.nextInt();

		while(numa!=0 && numa!=-1) { //if given input is wrong
			System.out.println(numa+" is not a legal choice");
			numa= key.nextInt();
		}



		Board b1 = null;

		if ((numa==0)) { //Creating default board


			b1 = new Board();

			for (int i=0;i<b1.board.length;i++) {
				System.out.println("\nLevel " + i + "\n-----------------");
				for(int j=0;j<b1.board[i].length;j++) {
					for(int k=0;k<b1.board[i][j].length;k++) {
						System.out.print(b1.board[i][j][k] + "\t");
						if(k==3)
							System.out.println();
						if(j==3 && k == 3)
							System.out.println();
					}
				}
			}
		}
		else if((numa==-1)){ // If user wants to use own level of board
			System.out.println("How many levels would you like?(minimum size 3, max 10");



			int numb = key.nextInt();	
			while (numb<3 || numb>10) {
				System.out.println(numb+ " is not a legal choice"); //Wrong input by user, must respect condition
				numb = key.nextInt();
			}





			System.out.println("What size do you want the nxn boards on each level to be?"); //Asking  user input to determine size of board

			System.out.println("Minimum size is 4x4, max is 10x10."); //must respect condition 

			System.out.println("==>Enter the value of n:");



			int numc = key.nextInt();
			while (numc<4 || numc>10) {
				System.out.println(numc+ " is not a legal choice");//wrong input
				numc = key.nextInt();
			}





			System.out.println("Your 3D board has been set up and looks like this:"); //Creating board from user input

			b1=new Board(numb,numc);
			for (int i=0;i<b1.board.length;i++) {
				System.out.println("\nLevel " + i + "\n-----------------");
				for(int j=0;j<b1.board[i].length;j++) {
					for(int k=0;k<b1.board[i][j].length;k++) {
						System.out.print(b1.board[i][j][k] + "\t");
						if(k==numc-1)
							System.out.println();
						if(j==numc-1 && k == numc-1)
							System.out.println();
					}
				}



			}
		}


		Player player0=null;
		Player player1=null;

		System.out.println("What is player 0's name (one word only):"); //Asking user for name of first player
		String p1 = key.next();
		System.out.println("What is player 1's name (one word only):");//Asking user for name of second player
		String p2 = key.next();
		player0 = new Player(p1); //Name stored in player class
		player1 = new Player(p2);

		Player [] players = new Player[2]; //Determining who start in the game using Math.random
		players[0] = player0;
		players[1] = player1;
		int first =(int)(Math.random() * ((2 - 1) + 1));
		Player personFirst=null;
		Player personSecond=null;

		if (0 == first) {
			personFirst = player0; //Determining if user 1  or 2 should start
			personSecond= player1;
		}
		else {
			personFirst = player1;
			personSecond= player0;
		}

		System.out.println("The game has begun, " +personFirst.getName()+ " goes first\n=========================" ); //Let the users know the game has begun


		//Let the games begin....

		game(personFirst, personSecond,b1); //Using static class of game(found below)





	}




	public static void game (Player p1,Player p2,Board b) { //static method 
		int x=0; int x2=0; int lastX; int lastX2; //Declaring variables
		int y =0; int y2=0;	int lastY; int lastY2;	
		int z=0; int z2=0;
		int temp=-1; 
		int numx = -1;
		String numz = null;

		int adj=0;
		int sum=0;
		int s = b.getSize();
		int l = b.getLevel();
		Dice d = new Dice();
		int el=0;
		int el2=0; 

		while ((z < l)&&(z2<l)) { //Players turns and rounds, if player 0 level is bigger than level of board

			System.out.println("It is "+p1.getName()+"'s turn"); //Announcing who is starting 
			d.rollDice();
			System.out.println(p1.getName()+" you rolled Die 1: "+d.getDice1()+" Die 2 : " +d.getDice2()); //Telling player their die rolls
			sum = d.getDice1()+d.getDice2();	//Storing the information of the dices
			lastX=x;
			lastY=y;

			x +=  (sum/s);
			y += (sum%s);

			if(((x>=s)&&(y>=s))){ //if row and column is bigger then size, means the level must change and must adjust for x and y.
				lastX=x;
				lastY=y;
				y = (y%s);
				x = ((x+1)/s);

				;

				adj = p1.getEnergy()+b.getEnergyAdj(z, x, y);
				p1.setEnergy(adj);

				z++;
			}else if(x>=s)  { //if only x(row) is bigger than the size, must increment to next level (must also recalculate for x)
				lastX=x;
				x = (x/s);


				adj = p1.getEnergy()+b.getEnergyAdj(z, x, y);
				p1.setEnergy(adj);
				z++;
			}
			else if(y>=s)  {//if only y(column) is bigger than the size, must increment to next level(must also recalculate y)
				lastY=y;
				y = (y%s);


				adj = p1.getEnergy()+b.getEnergyAdj(z, x, y);
				p1.setEnergy(adj);
				z++;
			}
			else if(z==l) {//If level of player 0 matches the level of the board 
				System.out.println(b+" for landing at ("+ x+ ","+y + ") at level " + (z-1));//Tells the location and level of player 0
				break;
			}
			else 
				if(z != l) //If level of player 0 does not matches the level of the board 
					adj = p1.getEnergy()+b.getEnergyAdj(z, x, y);
			p1.setEnergy(adj);
			if(z!=l)
				System.out.println(b+" for landing at ("+ x+ ","+y + ") at level " + (z)); //Tells the location and level of player 0

			if (x>=(s-1)&&(y>=(s-1))&&(z==(l-1))) { //If player 0 reaches the last square of the board, then winner of the game
				winner(p1.getName());
				break;
			}
			//Player 1's turn
			System.out.println("It is "+p2.getName()+"'s turn");//Announcing who is starting 
			d.rollDice();
			System.out.println(p2.getName()+" you rolled Die 1: "+d.getDice1()+" Die 2 : " +d.getDice2());//Telling player their die rolls
			sum = d.getDice1()+d.getDice2();	//Storing the information of the dices

			lastX2=x2;
			lastY2=y2;
			x2 +=  (sum/s);
			y2 += (sum%s);

			if(((x2>=s)&&(y2>=s))){ //if row and column is bigger then size, means the level must change and must adjust for x and y.
				lastX2=x2;
				lastY2=y2;
				y2 = (y2%s);
				x2 = ((x2+1)/s);
				;

				adj = p2.getEnergy()+b.getEnergyAdj(z2, x2, y2);
				p2.setEnergy(adj);
				z2++;
			}else if(x2>=s)  {//if only x(row) is bigger than the size, must increment to next level (must also recalculate for x)
				lastX2=x2;
				x2 = (x2/s);


				adj = p2.getEnergy()+b.getEnergyAdj(z2, x2, y2);
				p2.setEnergy(adj);
				z2++;
			}
			else if(y2>=s)  {//if only y(column) is bigger than the size, must increment to next level (must also recalculate for y)
				lastY2=y2;
				y2 = (y2%s);


				adj = p2.getEnergy()+b.getEnergyAdj(z2, x2, y2);
				p2.setEnergy(adj);
				z2++;
			}
			else if(z2==l) {//If level of player 1 matches the level of the board 
				System.out.println(b+" for landing at ("+ x2+ ","+y2 + ") at level " + (z2-1)); //Tells the location and level of player 1
				break;
			}
			else 
				if(z2 != l)//If level of player 1 does not matches the level of the board 
					adj = p2.getEnergy()+b.getEnergyAdj(z2, x2, y2);
			p2.setEnergy(adj);
			if(z2!=l)
				System.out.println(b+" for landing at ("+ x2+ ","+y2 + ") at level " + (z2));//Tells the location and level of player 1


			if (x2>=(s-1)&&(y2>=(s-1))&&(z2==(l-1))) { //If player 1 reaches the last square of the board, then winner of the game
				winner(p2.getName());
				break;
			}



			if ((x==x2)&&(y==y2)&&(z==z2)) { //if both players (player 0 and 1) have the same location, ask user what he wants to do


				System.out.println(p2.getName()  +"is at your new location");

				System.out.println("What do you want to do?");

				System.out.println("0 - Challenge and risk loosing 50% of your energy units if you loose or move to new location and get 50 % of other players energy units ");

				System.out.println("1 - to forfeit,you will move down one level at the same position.If at level 0, you lose 2 energy units and start at (0,0)");
				numx = key.nextInt();
				while(numx!=0&&numx!=1) {//Wrong input given, ask the user to re-enter correct input 
					System.out.println("Wrong option");
					System.out.print("Re-enter 0 or 1, please: ");
					numx = key.nextInt();
				}
				if (numx==0) {//Challenge input, will use random method to determine who wins the challenge
					int rando = (int) Math.random();

					if (rando<6) {
						System.out.println(p1.getName()+" lost the challenge"); //if player 0 loses challenge, loses half of the energy to player 1 and stays in same location
						p1.setEnergy(p1.getEnergy()/2);

						x=lastX2;
						y=lastY2;


					}
					else {System.out.println(p1.getName()+" won the challenge");//player 0 wins the challenge, steals half of the energy and location
					p2.setEnergy(p2.getEnergy()/2);

					x2=lastX;
					y2=lastY;

					}
				}
				else if (numx==1) { //If player 0 forfeit, he/she must go down by one level


					z2=z2-1;


				}


			}
			if (z!=l) { //Summarizes the round and asks user to press any key to continue
				System.out.println("At the end of this round:\n"+p2.getName()+" is on level "+z2+" at location ("+x2+","+y2+") and has "+p2.getEnergy()+" units of energy\n"+
						p1.getName()+" is on level "+z+" at location ("+x+","+y+") and has "+p1.getEnergy()+" units of energy\n");

				System.out.println("Press any key to continue next round ....");
				numz = key.next();

				System.out.println();
			}}




	}
	public static void winner(String s) { //Closing message once one of the player has won the round and closes the game
		System.out.println("The winner is "+s+". Well done!");
	}


}







