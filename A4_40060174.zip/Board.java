// -------------------------------------------------------
// Assignment (4)
// Written by: (Zahin Khan 40060174)
// For COMP 248 Section (EC-E) � Fall 2019
// --------------------------------------------------------

public class Board {//Creating class of board



	final static int MIN_LEVEL =3; //minimum level of board
	final static int  MIN_SIZE =3;//minimum size of board
	private int level; //levels of the board recorded


	static int ret;
	private int size;//row of the board
	private int size2;//column of the board
	public int[][][] board = null;//creating board

	public Board() { //default constructor if user wants a default board
		this.level=3;
		this.size = 4;
		createBoard(level,size);
	}

	public Board(int level, int size) { //constructor that allows to create a custom board with size and level
		this.level=level;
		this.size = size;
		createBoard(level, size);
	}

	private void createBoard(int l,int s) {//method that creates board using user input of size and level given
		board = new int [l][s][s];


		for (int i=0;i<board.length;i++) { //using for loops
			for(int j=0;j<board[i].length;j++) {
				for(int k=0;k<board[i][j].length;k++) {

					if ((j+k)!= 0 && (j+k+i)%3==0) {
						board[i][j][k] =-3;


					}
					else if ((j+k)!= 0 && (j+k+i)%5==0) {
						board[i][j][k] =-2;
					}
					else if ((j+k)!= 0 && (j+k+i)%7==0) {
						board[i][j][k] =2;

					}
					else 
						board[i][j][k]=0;



				}
			}
		}
	}
	//Accessor method for size (x coordinates)
	public int getSize2() {
		return size2;
	}

	//Accessor method for level		
	public int getLevel() {
		return level;
	}

	//Accessor method for size (y coordinates)
	public int getSize() {
		return size;
	}


	//Accessor method which returns energy adjustment value stored
	public int getEnergyAdj(int level, int size, int size2) {

		this.size2=size2;
		this.size=size;
		this.level=level;
		ret = board[level][size][size2];
		return ret;
	}


	//To string method returns a string showing energy adjustment values for each board at each level
	public String toString(){
		return "Your energy is adjusted by "+ ret;
	}

}
