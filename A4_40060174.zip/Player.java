// -------------------------------------------------------
// Assignment (4)
// Written by: (Zahin Khan 40060174)
// For COMP 248 Section (EC-E) � Fall 2019
// --------------------------------------------------------

public class Player { //Creating class of player
	private String Name;//Creating attributes for class
	private int level;
	private int x;
	private int y;
	private int energy;


	public Player() { //Default constructor for a player (starts off)
		this.Name = "";
		this.energy = 10;
		this.level=0;
		this.x = 0;
		this.y=0;
	}

	public Player(String playerName) {//Constructor that allows the name of players to be passed
		this.Name = playerName;
		this.energy = 10;
		this.x = 0;
		this.y=0;
		this.level=0;
	}


	public Player(int a,int b,int c) { //Constructor with 3 parameters
		this.level=a;
		this.x=b;
		this.y=c;
		this.energy = 10;
		this.Name = "";
	}

	public Player(Player a) {//copy constructor
		this.Name = a.Name;
		this.level = a.level;
		this.x = a.x;
		this.y = a.y;		
		this.energy = a.energy;
	}

	public String getName() {//Accessor for name of players
		return Name;
	}

	public int getLevel() {//Accessor for level 
		return level;
	}

	public int getX() {//Accessor of row of the board
		return x;
	}

	public int getY() {//Acessor of column of the board
		return y;
	}

	public int getEnergy() {//Accessor of energy
		return energy;
	}

	public void setName(String newName) {//Mutator for name 
		this.Name = newName;}

	public void setLevel(int newLevel) {//Mutator for level
		this.level = newLevel;}

	public void setX(int newX) {//Mutator for row of the board
		this.x = newX;}

	public void setY(int newY) {//Mutator for column of the board
		this.y = newY;}

	public void setEnergy(int newEnergy) {//Mutator of energy
		this.energy = newEnergy;}

	public void moveTo(Player p) {//Method of for moving players location
		this.level=p.level;
		this.x=p.x;
		this.y=p.y;

	}

	public boolean won(Board b) { //If player is last position of the board at the last level
		if ((this.x == b.getSize()-1)&&(this.y == b.getSize()-1)&&(this.level==b.getLevel())) {
			return true;
		}
		return false;

	}
	public boolean equals(Player p) {//Method to compare two objects
		if ((this.level==p.level)&&(this.x==p.x)&&(this.y==p.y)) {
			return true;
		}
		return false;


	}

	public String toString() {//To string that returns all the attributes of the class
		return "Something";
	}



}
