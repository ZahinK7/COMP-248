// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
// Assignment 2
// Written by: Zahin Khan 40060174
// For COMP 248 Section EC � Summer 2019
// Comments: Allowing the user to enter Uno card information (in required format) into the console and tell them what card they have 
// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------
import java.util.Scanner;
public class A2Q1 {
	public static void main(String args[]) {

		Scanner keyboard = new Scanner(System.in);

		System.out.println("     ----------------------------"); //Opening message
		System.out.println("      UNO Playing Card Describer");
		System.out.println("     ----------------------------");

		System.out.println(); // skipping a line

		System.out.println("Enter your playing card using the following notation:"); // Asking user to information about cards while following program instruction
		System.out.println("First character should be 0 to 9, W (for Wild), D (for Draw 2), S(for Skip), or V (for Reverse)");
		System.out.println("Second character should be R for red, G for green, B for blue or y for yellow");
		System.out.println();
		System.out.println("What is your card?");

		String w1 = keyboard.next(); // User's information is stored in declared string
		String upperWord = w1.toUpperCase(); // Converts information to upper case 

		
		if (w1.length() > 2) { //For case 1, users who have put more than 3 character will be notified the format is wrong
			System.out.println();//skipping a line
			System.out.println("You entered " + w1 + " which is not entered in the required format");
			System.exit(0);
		}

		if (w1.length() ==1 && upperWord.charAt(0) != 'W') { //For case 2, Notifies users that if you start a character with W, it is invalid
			System.out.println();//skipping a  line
			System.out.println("You entered " + w1 + " which is not a valid Uno card");
			System.exit(0);

		}else if (w1.length() ==1 && upperWord.charAt(0) == 'W') {// For case 3, if the first character of the information is W it will display Wild
			System.out.println();//skipping a line
			System.out.println("You entered " + w1 + " which is " + "Wild");
			System.exit(0);

		}
		if (upperWord.equals("W4") ) { // For case 4, if user enters W4, the console will display Wild draw 4
			System.out.println();//skipping a line
			System.out.println("You entered " + w1+ " which is" + " Wild Draw 4");
			System.exit(0);

		}
		String selec1 = "" + upperWord.charAt(0);
		String selec2 = "" + upperWord.charAt(1);


		switch(selec1) { //This is a switch statement to determine the type of card (first character)

		case "0" : // Case 0 to 9 is for the numbers
			selec1 = "Zero";
			break;

		case "1":
			selec1 = "One";
			break;

		case "2" :
			selec1 ="Two";
			break;

		case "3" :
			selec1 = "Three";
			break;

		case "4" :
			selec1 = "Four";
			break;

		case "5" :
			selec1 ="Five";
			break;

		case "6" :
			selec1 = "Six";
			break;

		case "7" : 
			selec1 = "Seven";
			break;

		case "8" :
			selec1 ="Eight";
			break;

		case "9" :
			selec1 = "Nine";
			break;

		case "D" :  // Case D is drawing 2 
			selec1 = "Draw 2" ;
			break;

		case "S": // Case S is Skip 
			selec1 = "Skip";
			break;

		case "V" :  // Case V is Reverse 
			selec1 = "Reverse";
			break;

		default: // When user has entered an invalid card
			System.out.println(); //skipping a line
			System.out.println("You entered " + w1 + " which is not a valid Uno card");
			System.exit(0);
			break;
		}
		
		switch(selec2) { // This is switch statement for the colours of the cards (second character)

		case "R" : 
			selec2 = "Red";
			break;

		case "G" : 
			selec2 = "Green";
			break;

		case "B" : 
			selec2 = "Blue";
			break;

		case "Y" : 
			selec2 = "Yellow";
			break;

		default:// When user has entered an invalid card
			System.out.println(); // Skipping a line
			System.out.println("You entered " + w1 + " which is not a valid Uno card");
			System.exit(0);
			break;
		}
		System.out.println();//skipping a line
		System.out.println("You entered " + w1+ " which is " + selec1 + " " + selec2); 

keyboard.close();//Closing scanner

	}
}