// ------------------------------------------------------------------------------------------------------------------------------------
// Assignment 2
// Written by: Zahin Khan 40060174
// For COMP 248 Section EC � Summer 2019
// Comments: Translating user's sentence into Ubbi Dubbi language 
// -----------------------------------------------------------------------------------------------------------------------------------
import java.util.Scanner;
public class A2Q2 {

	public static void main(String[] args) {

		System.out.println("\\\\--------------------------------------------------------"); // Opening message
		System.out.println("\\\\      Nancy's English to sentence2 Dsentence2 Translator Program   ");
		System.out.println("\\\\--------------------------------------------------------------");
		System.out.println();//skipping a line

		Scanner keyboard = new Scanner(System.in);
		System.out.println("Please enter the English sentence you want translated into Ubbi Dubbi"); // Asking the user for a sentence 
		System.out.println("(Be sure to have 1 space between words and to not have any spaces at the front and end of sentence):"); //Telling the user how to properly input 
		String sentence1 = keyboard.nextLine();//User's sentence is stored in a declared string
		sentence1 = sentence1.trim(); //Allows to remove beginning and end of a sentence put by user

		System.out.println("Translated sentence:"); // Displays the translated version of user's sentence to Ubbi Dubbi

        String word1="";
		for (int i = 0; i < sentence1.length(); i++) { // This loop allows to translate a character if it has a space 
		  if(sentence1.charAt(i)==' '){
				System.out.print(translateTosentence2(word1)+" ");
				word1="";
			  }else{ // If it is not the case, it will change the character of the sentence to word1 
				word1+=sentence1.charAt(i);
			 }
			  if(i==sentence1.length()-1){ //It prints the translation if we get the last character  
				System.out.println(translateTosentence2(word1));
				System.out.println("Have fun speaking it!!!!"); // Closing message 

			}
		}
		System.out.println();//skipping a line
	}

	static String translateTosentence2(String word1) { // Adding a ub in front of the word1 for this method 
		String sentence2 = ""; //sentence2 is used to add ubbi 
		if (word1.length() <= 2) {
			sentence2 += "ub" + word1.charAt(0);
			if (word1.length() == 2) {
				sentence2 += "ub" + word1.charAt(1);
			}
			return sentence2;
		}

		boolean vowel1 = false;
		for (int i = 0; i < word1.length(); i++) {
			if (theVowel(word1.charAt(i)) && !vowel1) {// If the last character of the string is ub, based on boolean, it would not add ub to user's sentence

				if (i == word1.length() - 1 && word1.charAt(i) == 'e') { // Adds ub to the character if the first statement fails 
					sentence2 += word1.charAt(i);
				} else {

					sentence2 += "ub" + word1.charAt(i); 
				}

				vowel1 = true;
			} else { 

				sentence2 += word1.charAt(i);

				if (!theVowel(word1.charAt(i)))
					vowel1 = false;
			}
		}
		return sentence2;
	}
	static boolean theVowel(char c) { //Checking if characters are a vowel
		String thevowels = "aeiou";//Declaring a string which are the variables
		String charac = "" + c;
		if (thevowels.contains(charac.toLowerCase())) { // Would happen if c is a vowel in lower case
			return true; 
		}
		return false; // Not happen if c is not a vowel		
	}
}